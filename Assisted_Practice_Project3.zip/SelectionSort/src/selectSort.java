import java.util.Scanner;

public class selectSort {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of elements:");
    	int length=sc.nextInt();
        int[] arr = new int[length];
        System.out.println("Enter the elements:");
        for(int i=0;i<length;i++)
        {
        	arr[i]=sc.nextInt();
        }
	   
	    selectionSort(arr);
	    System.out.println("The sorted elements are:");
	    for(int i:arr){

	        System.out.println(i);
	         }
	     }

	    public static void selectionSort(int[] arr){

	        for(int i=0;i<arr.length-1;i++){

	            int index =i;
	            for(int j=i+1;j<arr.length;j++){
	                if(arr[j]<arr[index]){

	                    index =j;
	                }

	            }
	            int smallNumber = arr[index];
	            arr[index]= arr[i];
	            arr[i]= smallNumber;
	        }

	    }

}

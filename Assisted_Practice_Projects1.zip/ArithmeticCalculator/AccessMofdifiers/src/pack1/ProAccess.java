package pack1;

public class ProAccess {
	
		protected void display() 
	    { 
	        System.out.println("This is a protected access specifier!"); 
	    } 
}

	





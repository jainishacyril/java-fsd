package pack2;
import pack1.*;
public class ProAccessMod extends ProAccess{
	public static void main(String[] args) {
		ProAccessMod obj = new ProAccessMod ();   
	       obj.display();  
	}


}

package pack4;
import pack3.*;
public class PubAccessMod extends PubAccess{
public static void main(String[] args) {
		
		PubAccessMod obj = new PubAccessMod(); 
        obj.display();  
		
	}

}

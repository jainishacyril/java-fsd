package pack1;

public class ProAccess {
	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 

}

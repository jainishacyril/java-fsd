package def;
//default access modifier
class defaultAccess
{ 
  void display() 
     { 
         System.out.println("You are using defalut access specifier"); 
     } 
} 
//private access modifier
class privAccess
{ 
   private void display() 
    { 
        System.out.println("You are using private access specifier"); 
    } 
} 



public class AccessMod {
	public static void main(String[] args) {
		//default
		System.out.println("Dafault Access Specifier:");
		defaultAccess obj = new defaultAccess(); 		  
        obj.display(); 

        System.out.println("Private Access Specifier:");
		privAccess  obj1 = new privAccess(); 
        //trying to access private method of another class 
        //obj.display();

	}

}

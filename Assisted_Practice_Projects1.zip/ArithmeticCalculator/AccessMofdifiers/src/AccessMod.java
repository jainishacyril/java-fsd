
class defAccessSpecifier{
void display() 
     { 
         System.out.println("You are using defalut access specifier"); 
     } 
} 

class priaccessspecifier 
{ 
   private void display() 
    { 
        System.out.println("You are using private access specifier"); 
    } 
} 


public class AccessMod {
	public static void main(String[] args) {
		//default
		System.out.println("Dafault Access Specifier:");
		defAccessSpecifier obj = new defAccessSpecifier(); 		  
        obj.display(); 
        
        System.out.println("Private Access Specifier:");
		priaccessspecifier  obj1 = new priaccessspecifier(); 
		//while executing this [obj1.display();] 
		//It won't print the display method as we put it in a private method
		//using private access specifier


	}
}

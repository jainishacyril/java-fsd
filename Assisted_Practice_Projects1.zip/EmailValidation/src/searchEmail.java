import java.util.Scanner;
import java.util.ArrayList;
import java.util.regex.*;
public class searchEmail {

	public static void main(String[] args) {
		
		    ArrayList<String> emailID = new ArrayList<String>();
		        
		        emailID.add("serah.hasly@gmail.com");
		        emailID.add("daisy.kelly@gmail.com");
		        emailID.add("olivia.fallon@gmail.com");
		        emailID.add("romeo.ramirez@gmail.com");
		        emailID.add("henry.wood@gmail.com");
		        emailID.add("laura.hughes@gmail.com");
		        emailID.add("sabrina.carter@gmail.com");
		        emailID.add("samuel.jonathan@gmail.com");
		        emailID.add("marshell.evans@gmail.com");
		        emailID.add("yukki.jane@gmail.com");
		        
		        String searchEmail;
		        System.out.println("E-mail: ");
		        Scanner scanner = new Scanner(System.in);
		        searchEmail = scanner.nextLine();
		        String regex = "^(.+)@(.+)$";
		        Matcher matcher = Pattern.compile(regex).matcher(searchEmail);
		        if (matcher.matches() && emailID.stream().anyMatch(mail -> mail.equals(searchEmail))) {
		            System.out.println(searchEmail + " is found");
		        } else {
		            System.out.println(searchEmail + " is not found");
		        }

			}

		}


	



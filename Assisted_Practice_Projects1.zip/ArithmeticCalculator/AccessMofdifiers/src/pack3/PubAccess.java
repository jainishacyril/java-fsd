package pack3;

public class PubAccess {
	public void display() 
    { 
        System.out.println("This is a public access specifier!"); 
    } 
}

import java.util.Arrays;
import java.util.Scanner;

public class exponentialSearch {

public static  void main(String[] args){


	Scanner sc = new Scanner(System.in);
    System.out.println("Enter number of elements:");
	int length=sc.nextInt();
    int[] arr = new int[length];
    System.out.println("Enter the elements:");
    for(int i=0;i<length;i++)
    {
    	arr[i]=sc.nextInt();
    }
    System.out.println("Enter the element to be searched");
    int value = sc.nextInt();
    int outcome = exponentialSearch(arr,length,value);

    if(outcome<0){

       System.out.println( "Element is not present in the array");

    }else {

        System.out.println( "Element is  present in the array at index :"+outcome);
    }

        }

        public static int exponentialSearch(int[] arr ,int length, int value ){

        if(arr[0]==value){
            return 0;
            }
        int i=1;
        while(i<length && arr[i]<=value){

            i=i*2;
        }
        return Arrays.binarySearch(arr,i/2,Math.min(i,length),value);
        }


}

